describe('util', function () {
    require('./removeIgnores');
    require('./download');
    require('./isPathAbsolute');
    require('./relativeToBaseDir');
    require('./createLink');
});
